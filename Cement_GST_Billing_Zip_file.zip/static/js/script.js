const qty = document.getElementById("qty");
const rate = document.getElementById("rate");
const gstSpan = document.getElementById("gst");
const totalSpan = document.getElementById("total");

function calculate(){
    const q = qty.value || 0;
    const r = rate.value || 0;
    const subtotal = q * r;
    const gst = subtotal * 0.18;
    const total = subtotal + gst;

    gstSpan.innerText = gst.toFixed(2);
    totalSpan.innerText = total.toFixed(2);
}

qty?.addEventListener("input", calculate);
rate?.addEventListener("input", calculate);
