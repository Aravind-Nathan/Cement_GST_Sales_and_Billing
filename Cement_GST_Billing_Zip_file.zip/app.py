from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

def get_db():
    return sqlite3.connect("database.db")

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        customer = request.form["customer"]
        qty = int(request.form["qty"])
        rate = float(request.form["rate"])

        subtotal = qty * rate
        gst = subtotal * 0.18
        total = subtotal + gst

        db = get_db()
        db.execute(
            "INSERT INTO sales (customer, qty, rate, gst, total) VALUES (?, ?, ?, ?, ?)",
            (customer, qty, rate, gst, total)
        )
        db.commit()
        db.close()

        return redirect("/invoices")

    return render_template("index.html")

@app.route("/invoices")
def invoices():
    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT * FROM sales")
    data = cur.fetchall()
    db.close()
    return render_template("invoices.html", invoices=data)

if __name__ == "__main__":
    app.run(debug=True)
