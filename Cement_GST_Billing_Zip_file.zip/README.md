Enhanced Cement Sales & GST Billing Web App

Features:
- Modern UI (Vanilla CSS)
- Live GST & total preview
- Invoice dashboard
- Flask backend + SQLite

Run:
pip install flask
python app.py
